#!/bin/bash
cd "$(dirname "$0")"
if [ ! -d "node_modules" ]; then
    echo "安装依赖..."
    npm install --production
fi
echo "启动 Marked AI..."
echo "访问: http://localhost:3000"
NODE_ENV=production node server.mjs
