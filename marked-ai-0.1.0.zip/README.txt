Marked AI Server (Bundled)
==========================

快速开始:
1. 运行 start.sh (Mac/Linux) 或 start.bat (Windows)
2. 访问 http://localhost:3000

环境变量:
- PORT=3000
- DATA_DIR=~/.marked-ai
- ANTHROPIC_API_KEY=your-key

系统要求:
- Node.js 18+
